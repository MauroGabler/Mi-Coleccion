const { cargar_consulta } = require('../helpers/funciones')

const consultar = async (params) => {

  let respuesta = {}
  respuesta['categoria_coleccion'] = {}
  let where = ''
  
  if (params.int_id_cat_coleccion) {
    let int_id_cat_coleccion = params['int_id_cat_coleccion']
    where += `WHERE int_id_cat_coleccion = ${int_id_cat_coleccion}`
  }

  let sel = `SELECT
            int_id_cat_coleccion, var_nom_cat, bool_activa
            FROM categoria_coleccion
            ${where}`

  const res = await cargar_consulta(sel)

  res.forEach(c => {

    let categoria = {}

    categoria['int_id_art'] = c[0]
    categoria['var_nom_art'] = c[1]
    categoria['venta_int_id_venta'] = c[2]

    respuesta.categoria_coleccion.push(categoria)
  })

  return respuesta
}

const guardar = async (params) => {

  let respuesta = {}
  respuesta['mensaje'] = 'Se ha guardado una categoria'
   
  let var_nom_cat = params?.var_nom_cat

  if (var_nom_cat == undefined) {
    return respuesta['mensaje'] = 'No ha enviado el nombre de categoria'
  } 

  const sel = `SELECT COUNT(int_id_cat_colecc)
              FROM categoria_coleccion`
  const id = cargar_consulta(sel)

  const ins = `INSERT INTO categoria_coleccion
               (int_id_cat_colecc, var_nom_cat)
               VALUES
               (${id}, ${var_nom_cat})`
  cargar_consulta(ins)

  return respuesta
}

module.exports = {
  consultar,
  guardar
}