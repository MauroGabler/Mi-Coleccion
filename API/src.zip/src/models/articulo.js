const { cargar_consulta } = require('../helpers/funciones')
// const { param } = require('../routes/usuario')

const consultar = async (params) => {

  let respuesta = {}
  respuesta['articulos'] = {}
  let where = ''
  
  if (params.int_id_art) {
    let int_id_art = params['int_id_art']
    where += `WHERE int_id_art = ${int_id_art}`
  }

  let sel = `SELECT
            int_id_art, var_nom_art, venta_int_id_venta
            FROM articulo
            ${where}`

  const res = await cargar_consulta(sel)

  res.forEach(a => {

    let articulo = {}

    articulo['int_id_art'] = a[0]
    articulo['var_nom_art'] = a[1]
    articulo['venta_int_id_venta'] = a[2]

    respuesta.articulos.push(articulo)
  })

  return respuesta
}

const guardar = async (params) => {

  let respuesta = {}
  respuesta['mensaje'] = 'Se ha guardado un artículo'
   
  let var_nom_art = params?.var_nom_art
  let venta_int_id_venta = params?.venta_int_id_venta

  if (var_nom_art == undefined) {
    return respuesta['mensaje'] = 'No ha enviado el nombre del artículo'
  } 

  if (venta_int_id_venta == undefined) {
    return respuesta['mensaje'] = 'No ha enviado el código de venta asociado al artículo'
  }

  const sel = `SELECT COUNT(int_id_art)
              FROM articulo`
  const id = cargar_consulta(sel)

  const ins = `INSERT INTO articulos
               (int_id_art, var_nom_art, venta_int_id_venta)
               VALUES
               (${id}, ${var_nom_art}, ${venta_int_id_venta})`
  cargar_consulta(ins)

  return respuesta
}

module.exports = {
  consultar,
  guardar
}