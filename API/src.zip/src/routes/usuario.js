const { Router } = require('express')
const { consultar, guardar } = require('../models/usuario')

const router = Router()

router.get('/usuario', async (req, res) => {
  const parametros = req.body
  const respuesta = await consultar(parametros)
  res.json(respuesta)
})

router.post('/usuario', async (req, res) => {
  const parametros = req.body
  console.log(parametros)
  const respuesta = await guardar(parametros)
  res.json(respuesta)
})

module.exports = router