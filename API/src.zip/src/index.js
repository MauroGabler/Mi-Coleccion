const express = require('express')
const cors = require('cors')

const app = express()
const port = 3000

app.use(express.json())
app.use(cors())
app.use('/API', require('./routes/usuario.js'))

app.listen(port, () => console.log('nodeOracleRestApi app listening on port %s!', port))